package supernote.generated.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({
    ElementType.METHOD,
    ElementType.FIELD,
    ElementType.RECORD_COMPONENT,
    ElementType.PARAMETER
})
@Retention(RetentionPolicy.SOURCE)
public @interface SupernotePluginExport {}
